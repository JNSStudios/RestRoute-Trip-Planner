

function App() {
    
    return (
        <>
            <h1>RestRoute Trip Planner</h1>

        
        
        </>
    );
}